# 开发进度

更新日期：2026-11-01｜需求1.3｜实施契约1.2｜当前推荐阶段：**D0，ready_to_start**。

本轮已完成设计复审/必要修订/开发准备；未开始业务编码、依赖安装、数据库初始化或软件测试。文档校验与数据离线复算不计作任何开发阶段通过。

| 阶段 | local_status | external_status | overall_status | 当前证据/下一动作 |
| --- | --- | --- | --- | --- |
| D0 工程与配置 | not_started | not_applicable | not_started | 已有任务卡；下一步建立真实最小工程与锁、配置/健康检查 |
| D1 PostgreSQL/只读 | not_started | not_applicable | not_started | 等D0本地门与真实PG环境 |
| D2 只读Harness/Web | not_started | not_started | not_started | 模型未配置；本地可用替身但仍须D1完成 |
| D3 受控写闭环 | not_started | not_started | not_started | 等D2本地门；真实闭环未验证 |
| D4 记忆/完整交互 | not_started | not_started | not_started | 等D3本地门 |
| D5 非功能/回归 | not_started | not_started | not_started | 等D4本地门 |
| D6 部署/交付 | not_started | not_started | not_started | 候选材料可按依赖准备；最终门需全部live/环境/通知 |
| D7 可选增强 | not_started | not_applicable | not_in_scope | FR-017/018/跨企业金额未默认纳入 |

## 外部条件台账

| ID | 状态 | 缺少证据 | 不阻断的工作 |
| --- | --- | --- | --- |
| EXT-MODEL | unverified | 已选 DeepSeek 官方渠道；拟优先验证 `deepseek-flash`，`deepseek-v4-pro` 为对照候选；账号、预算、实际连通性及工具链 probe 待验证 | D0/D1、D2—D5本地分支 |
| EXT-ENV | partially_observed | 开发和验证使用用户当前机器；历史探测Python 3.13.9/Node 24.8.0；uv/Docker/PostgreSQL/客户端/镜像与构建未验证 | 不依赖缺失运行时的契约/纯逻辑/文件准备；不能以此通过集成门 |
| EXT-NOTICE | awaiting_source | 用户负责核验正式截止、入口、大小及演示载体 | 全部开发与候选交付准备 |
| EXT-POLICY | awaiting_confirmation | Q-007最终历史保留/彻底擦除要求 | 当前保守政策与删除停止未来输入 |

外部条件台账于 2026-11-03 同步，详见[项目需求速览与决策清单](../requirements/00_项目需求速览与决策清单.md)。

## 测试与问题状态

- 61项TC定义初始均not_run；其中TC040/041/050增强未纳入；47项Must AC尚无软件通过记录。
- 17项复审问题已登记；P0/P1设计处置已补，运行验证仍未执行。REV-015外部证据保持待验证。
- 当前无阶段实现报告；reports仅含本轮设计来源/验证与报告规范。
- 原需求/官方材料不修改；当前不是Git仓库，未执行git init/commit。

更新本文件时必须同时链接实际阶段报告和证据，记录失败/阻塞原因及下一可执行任务；状态定义以[总计划](02_开发实施总计划.md)为准。
